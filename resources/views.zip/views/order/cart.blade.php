<div class="ataas">
    <h2>cart</h2>
    <table class="table" id="tbl-cart">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Qty</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</div>

<style>
    .ataas{
        margin-top: 110px
    }
</style>
