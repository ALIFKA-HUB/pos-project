<script>
    $(function() {
        const orderedList = [];
        let total = 0;

        $('.btn-add').on('click', function() {
            const name = $(this).closest('.card-body').find('.card-title').text();
            const price = Number($(this).closest('.card-body').find('h3').text());
            const id = $(this).closest('.card-body').find('.id_product').val();

            // Cek apakah produk sudah ada di daftar
            const index = orderedList.findIndex(list => list.id == id);

            if (index === -1) {
                // Jika belum ada → tambahkan produk baru
                const newData = {
                    id: id,
                    name: name,
                    qty: 1,
                    price: price,
                    total: price
                };
                orderedList.push(newData);

                let row = `
                <tr id="row-${id}">
                    <td>${name}</td>
                    <td class="qty">${newData.qty}</td>
                    <td class="total">${newData.total}</td>
                </tr>
            `;
                $('#tbl-cart tbody').append(row);
            } else {
                // Jika sudah ada → update qty dan total harga
                orderedList[index].qty += 1;
                orderedList[index].total = orderedList[index].qty * orderedList[index].price;

                // Update tampilan di tabel
                $(`#row-${id} .qty`).text(orderedList[index].qty);
                $(`#row-${id} .total`).text(orderedList[index].total);
            }

            console.log(orderedList);
        });
    });
</script>
